![caughy-up-now](./assets/caughy-up-now.webp)



<iframe width="640" height="360" scrolling="no" frameborder="0" style="border: none;" src="https://www.bitchute.com/embed/gyttv4NHJGyp/"></iframe>



**Revelation 3.10**
Because thou hast kept the word of my patience, I also will keep thee from the hour of temptation, which shall come upon all the world, to try them that dwell upon the earth.

---

**Revelation 4.1**
After this I looked, and, behold, a door was opened in heaven: and the first voice which I heard was as it were of a trumpet talking with me; which said, Come up hither, and I will shew thee things which must be hereafter.

**Revelation 4.2**
And immediately I was in the spirit: and, behold, a throne was set in heaven, and one sat on the throne.

**Revelation 4.3**
And he that sat was to look upon like a jasper and a sardine stone: and there was a rainbow round about the throne, in sight like unto an emerald.

**Revelation 4.4**
And round about the throne were four and twenty seats: and upon the seats I saw four and twenty <font color="#00b050">elders</font> sitting, clothed in white raiment; and they had on their heads crowns of gold.

---

**Revelation 4.10**
The four and twenty <font color="#00b050">elders</font> fall down before him that sat on the throne, and worship him that liveth for ever and ever, and cast their crowns before the throne, saying,

**Revelation 4.11**
Thou art worthy, O Lord, to receive glory and honour and power: for thou hast created all things, and for thy pleasure they are and were created.

---

**Exodus 23.10-11**
10 And six years thou shalt sow thy land, and shalt gather in the fruits thereof:

11 But the seventh _year_ thou shalt let it rest and lie still; that the poor of thy people may eat: and what they leave the beasts of the field shall eat. In like manner thou shalt deal with thy vineyard, _and_ with thy oliveyard.

---

**Leviticus 23.22**
22  And when ye reap the harvest of your land, thou shalt not make clean riddance of the corners of thy field when thou reapest, neither shalt thou gather any gleaning of thy harvest: thou shalt leave them unto the poor, and to the stranger: I _am_ the Lord your God.

---

**Matthew 24.29**
Immediately after the tribulation of those days shall the sun be darkened, and the moon shall not give her light, and the stars shall fall from heaven, and the powers of the heavens shall be shaken:

**Matthew 24.30**
And then shall appear the sign of the Son of man in heaven: and then shall all the tribes of the earth mourn, and they shall see the Son of man coming in the clouds of heaven with power and great glory.

**Matthew 24.31**
And he shall send his angels with a great sound of a trumpet, and they shall gather together his elect from the four winds, from one end of heaven to the other.

---

**1 Thessalonians 5**
BUT of the times and the seasons, brethren, ye have no need that I write unto you.

2 For yourselves know perfectly that the day of the Lord so cometh as a thief in the night.

3 For when they shall say, Peace and safety; then sudden destruction cometh upon them, as travail upon a woman with child; and they shall not escape.

4 But ye, brethren, are not in darkness, that that day should overtake you as a thief.

5 Ye are all the children of light, and the children of the day: we are not of the night, nor of darkness.

6 Therefore let us not sleep, as _do_ others; but let us watch and be sober.

7 For they that sleep sleep in the night; and they that be drunken are drunken in the night.

8 But let us, who are of the day, be sober, putting on the breastplate of faith and love; and for an helmet, the hope of salvation.

9 For God hath not appointed us to wrath, but to obtain salvation by our Lord Jesus Christ,

10 Who died for us, that, whether we wake or sleep, we should live together with him.

11 Wherefore comfort yourselves together, and edify one another, even as also ye do.

12 And we beseech you, brethren, to know them which labour among you, and are over you in the Lord, and admonish you;

13 And to esteem them very highly in love for their work’s sake. _And_ be at peace among yourselves.

14 Now we exhort you, brethren, warn them that are unruly, comfort the feebleminded, support the weak, be patient toward all _men_.

15 See that none render evil for evil unto any _man;_ but ever follow that which is good, both among yourselves, and to all _men_.

16 Rejoice evermore.

17 Pray without ceasing.

18 In every thing give thanks: for this is the will of God in Christ Jesus concerning you.

19 Quench not the Spirit.

20 Despise not prophesyings.

21 Prove all things; hold fast that which is good.

22 Abstain from all appearance of evil.

23 And the very God of peace sanctify you wholly; and _I_ _pray_ _God_ your whole spirit and soul and body be preserved blameless unto the coming of our Lord Jesus Christ.

24 Faithful _is_ he that calleth you, who also will do _it_.

25 Brethren, pray for us.

26 Greet all the brethren with an holy kiss.

27 I charge you by the Lord that this epistle be read unto all the holy brethren.

28 The grace of our Lord Jesus Christ _be_ with you. Amen.

            ¶ The first _epistle_ unto the Thessalonians was written from Athens.

---

<iframe width="560" height="315" src="https://www.youtube.com/embed/FpFGvSSEh28?si=VNGwT95PfRfEg2NB" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe>

---

<iframe width="560" height="315" src="https://www.youtube.com/embed/rwFsyFJ_-38?si=N5o-qA1-2DoE1q06" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe>

---

<iframe width="560" height="315" src="https://www.youtube.com/embed/ejt_5XQo-9Y?si=yz6DqC2hRRT3H005" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe>



---

![The-road-to-salvation](./assets/The-road-to-salvation.webp)

[Download the document here](assets/the-road-to-salvation.pdf) 





---

![sites-of-interest](./assets/sites-of-interest.webp)

## J.D. Farag
[Website](https://www.jdfarag.org/)
[YouTube](https://www.youtube.com/@JDFaragTV)

---

## Watchman River
[WebSite](https://watchmanriver.org/)
[YouTube](https://www.youtube.com/@WatchmanRiver)

---

## Faith In The Fire 777

[YouTube](https://www.youtube.com/@FaithInTheFire777)

---

## Encourage Men

[Blog 4 encouragements](https://encouragemen.blog/blog/)

---

## Generation2434
[YouTube](https://www.youtube.com/@Generation2434)

---

## Last Days AWAKENING
[YouTube](https://www.youtube.com/@LastDaysAWAKENING)

---

## Red Letter Radio
[BitChute](https://www.bitchute.com/channel/hke6emnNyvWj/)

---
## REV310
[WebSite](https://www.rev310.net/)

---

## Pastor D
[Dean Odle](https://www.deanodle.org/)

---

## Mark Hemans
[Jesus Encounter Ministries](https://www.jesusencounterministries.com/)
[YouTube](https://www.youtube.com/channel/UCmMLO7vxbA78hTr6EgguIYA)

---

## Jamie Walden
[Omega Dynamics](https://www.omegadynamics.org/)
[Buffalo Base Camp](https://www.calicobuffalobasecamp.com/)
[YouTube](https://www.youtube.com/@jamiewalden756)

---

## Richie From Boston
[richiefromboston.tv](https://richiefromboston.tv/)
[BitChute](https://www.bitchute.com/channel/juH53r3AyWVW/)
[TikTok](https://www.tiktok.com/@richiefromboston)

---

## Jason Zelda
[YouTube](https://www.youtube.com/@jasonzelda/featured)

---

## The Last Reformation
[thelastreformation.com](https://thelastreformation.com/)
[Map](https://map.thelastreformation.com/#)
[YouTube](https://www.youtube.com/@TheLastReformation)
[Friends of Torben](https://friendsoftorben.com/)

---

## Edith Neumaier
[BitChute](https://www.bitchute.com/channel/OVxXA0uDWdVr/)
ㅤ
___
## Growing in the Gospel with Cary Schmidt
[YouTube](https://www.youtube.com/@pastorcaryschmidt)

---

![telegram](./assets/telegram.webp)



[Behold Israel](https://t.me/s/beholdisraelchannel)

[Generation2434](https://t.me/s/Generation2434)

[Watchman River](https://t.me/s/WatchmanRiverTom)

---

![download-this-website](./assets/download-this-website.webp)

[Here](./assets/public_html.zip)
