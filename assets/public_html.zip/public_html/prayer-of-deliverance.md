

![logo-1](./assets/logo-1.webp)

---

<iframe width="640" height="360" scrolling="no" frameborder="0" style="border: none;" src="https://www.bitchute.com/embed/QkS85klDiARF/"></iframe>



---

We are *praying* to ***Jesus*** the ***deliverer***.

Lord ***Jesus Christ***, I *believe* that you are the ***Son of God***.

And the only ***Way*** to ***God the Father***.

That ***You*** died on the *cross* for *my sins*, and *rose again* from the dead.

I come to ***You*** now, for *mercy*, and for *forgiveness*.

I believe ***You*** do *forgive me*, and *receive* me as ***Your*** *child*.

And because ***You*** *receive* me, I *receive* myself, *as a child of God*.

And now ***Lord***, ***You*** know the *special problem* I have.

The *demonic influences* that *torment* me.

***Lord*** I want to *meet* ***Your*** *conditions*, and receive ***Your*** *deliverance*.

First of all, I *forgive every other person*, who ever *harmed or wronged me*.

*I forgive them all now*.

---

- **Take time to go through the list of people you need to forgive**
- **before proceeding with this prayer.**
- **If there is anyone on your heart, that you need to be forgiven by.**
- **Then please let the Holy Spirit lead you, in what to do.**
- **You can not force others to forgive you, and in that case it's enough that Jesus Christ has forgiven you.**
- **The bible teaches us, that we are to confess our sins one to another.**

---

***Lord*** I have *forgiven* all these *people*, I have *laid down all bitterness*,

*all resentment, all hatred, and all rebellion*.

And I *believe* ***You*** have *forgiven* me. I *thank* ***You*** for it ***Lord***.

I also *renounce every contact*, with satan, with *occult power*,

with *secret societies*, With any thing in satan's *territory*.

I repent of being in that *territory*, and I turn my *back* on it now.

Also ***Lord*** if there is a *curse* on my life, I thank ***You***, that on the cross,

***You*** were made a *curse*, that I might be redeemed from the *curse*,

and receive the *blessing*, and I claim that *blessing* now.

*Release* from the *curse*, and *entering into the blessing*.

And now ***Lord*** I want to *come against*, any *evil spirit* in me,

that *occupies* any *area* of my *personality*.

I want to tell ***You***, I *hate* them, they are *my enemies*.

I will not make *peace* with them, I will not *compromise* with them.

*They* will have *no more place* in me, I turn *against* them now,

and in the *authority* of ***Your Name Jesus***, I *command them* to leave me.

I *expel them* right now, in the Name of ***Jesus Christ***.

![logo-2](./assets/logo-2.webp)

---

