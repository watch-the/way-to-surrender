___

![The-road-to-salvation](./assets/The-road-to-salvation.webp)

Dear Heavenly ***Father***
You know *everything* about me,
and you know that I’m a *sinner*.



For many years, I have *loved my sins*.
I hereby *repent* from all *my sinful ways*.



I’m willing to *change with **Your** help*,
I receive your *forgiveness*, and I pray that ***you** help me*
*forgive* those, who have *hurt me*.



I know I only receive *forgiveness*, as I *forgive others*.



Thank You that *Jesus **Christ** died* on the cross for *us all*.
Thank You that He offers His *righteousness* to me,
and today this very day, I receive that *righteousness*.



I *hereby* put my *faith* in Him, the ***savior*** of the world.
So please God have *mercy* on me, a *sinner*.
***Save me Jesus Christ***, and today this very day,
***I commit my life to you Lord Jesus Christ***.

![amen](./assets/amen.webp)

---

